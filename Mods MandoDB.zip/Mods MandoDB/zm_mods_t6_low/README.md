cwz-medium.gsc -> For good configuration
cwz-low.gsc    -> For little configuration

How to add mods on your zombie t6 ?

Steps :

- Win + R
- paste ->    %localappdata%\Plutonium\storage\t6     and enter
- Create a folder with the name ->    scripts
- enter into the folder
- create folder with the name ->  zm 
- and a folder with the name ->   mp          WARNING: DO THAT IN THE SAME FOLDER (scripts)
- enter in the folder ->   zm
- paste all file in this folder               WARNING: DON'T PASTE THE FOLDER zm_mods_t6 ! PASTE ONLY THE FILES


Start the game (DONT START THE GAME IN PUBLIC PARTY). You need to be restart the game if your changer/upload/remove a mod.

----------------------------------------------------------------------------------------------------------------------------------

UPDATE :

## General
- No perk limit
- Unlimited sprint
- Max ammos refill weapon clips
- Zombie health capped at 10,000
- HUD additions: Health bar, field upgrades and self revives
- Zombies Counter
- Shield Meter
- Magic Box Share

## Field Upgrades
- Aether Shroud:
   - Player's are undetected by zombies and move faster for 8 seconds
   - Press the ACTION SLOT THREE button/ALT FIRE button to activate
   - Exclusive to Green Run, Die Rise and Buried
- Frenzied Guard:
   - Grants invulnerability for 15 seconds
   - Press the ACTION SLOT THREE button/ALT FIRE button to activate
   - Exclusive to Nuketown, Mob of the Dead and Origins

## Perks
- Quick Revive:
  -  Health regeneration
- Stamin-up:
  - Move even faster
  - No fall damage
  - Walk faster while aiming
- Speed Cola:
  - Swap weapons faster
- Mule Kick:
  - Repurchasing the perk restores the player's lost weapon
  - Credit to Jbleezy: https://github.com/Jbleezy/BO2-Reimagined

## Texture Pack
- Perk machines
- Perk icons
- Power-up icons
- Team icons
- Rank icons
- Field upgrade HUD 
- Self revive HUD
